import dk.sdu.cbse.common.IEntityProcessorService;
import dk.sdu.cbse.common.IGamePluginService;
import dk.sdu.cbse.common.IPostEntityProcessorService;

module Asteroids {
    requires Common;
    requires javafx.graphics;

    exports dk.sdu.cbse.asteroid;


}