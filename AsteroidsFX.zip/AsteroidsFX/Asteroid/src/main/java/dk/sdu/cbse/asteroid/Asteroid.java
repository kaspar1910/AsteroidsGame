package dk.sdu.cbse.asteroid;

import dk.sdu.cbse.common.Entity;

public class Asteroid extends Entity {

    private int splitLevel;

    public int getSplitLevel() {
        return splitLevel;
    }

    public void setSplitLevel(int splitLevel) {
        if (splitLevel < 0) {
            throw new IllegalArgumentException("Split level cannot be negative.");
        }

        this.splitLevel = splitLevel;
    }
}