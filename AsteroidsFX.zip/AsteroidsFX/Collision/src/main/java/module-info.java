module Collision {
}