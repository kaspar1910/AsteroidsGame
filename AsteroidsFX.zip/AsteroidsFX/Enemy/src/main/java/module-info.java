module Enemy {
}